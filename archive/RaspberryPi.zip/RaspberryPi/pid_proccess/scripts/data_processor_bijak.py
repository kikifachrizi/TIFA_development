#!/usr/bin/env python

import rospy
import tf2_ros
import tf2_geometry_msgs
import math
from geometry_msgs.msg import PoseStamped, PointStamped, Twist
from std_msgs.msg import String

# Initialize arrays
kp = [1.0, 2.0, 1.0] 
ki = [0.0011, 0.0011, 0.0011]
kd = [0.00, 0.00, 0.00]
pose = [0, 0, 0]

# Target position in global frame
target_position = {"x": 1.0, "y": 0.0, "z": 0}

error = [0, 0, 0]
prev_error = [0, 0, 0]
p = [0, 0, 0]
i = [0, 0, 0]
d = [0, 0, 0]
output = [0, 0, 0]

# PID gains and velocity limits
 # Proportional gains
vmaxrot = 1.0  # Max rotational velocity
vmaxtrans = 1.0  # Max translational velocity
thetta = 0  # Angle

def poseupdate_callback(msg):
    global pose, output, twist_msg

    try:
        # Prepare global positionc,
        position_global = PointStamped()
        position_global.header.frame_id = "map"
        position_global.header.stamp = rospy.Time(0)
        position_global.point = msg.pose.position
        yaw = msg.pose.orientation

        # Set pose from global position
        pose[0] = position_global.point.x
        pose[1] = position_global.point.y
        pose[2] = yaw.z  # Using z component of orientation

        # Set setpoint
        setpoint = [target_position["x"], target_position["y"], target_position["z"]]

        # PID control loop
        for ii in range(3):
            error[ii] = setpoint[ii] - pose[ii]

            # Handle angle wrapping for rotation
            if ii == 2:
                if error[ii] > 180:
                    setpoint[ii] -= 360
                    error[ii] = setpoint[ii] - pose[ii]
                elif error[ii] < -180:
                    setpoint[ii] += 360
                    error[ii] = setpoint[ii] - pose[ii]

            # Calculate PID components
            p[ii] = kp[ii] * error[ii]
            i[ii] += ki[ii] * error[ii]
            d[ii] = kd[ii] * (error[ii] - prev_error[ii])

            prev_error[ii] = error[ii]

            # Limit integral term
            if ii == 2:
                i[ii] = max(min(i[ii], vmaxrot), -vmaxrot)
            else:
                i[ii] = max(min(i[ii], vmaxtrans), -vmaxtrans)

            # Calculate output
            output[ii] = p[ii] + i[ii] + d[ii]

            # Limit output
            if ii == 2:
                output[ii] = max(min(output[ii], vmaxrot), -vmaxrot)
            else:
                output[ii] = max(min(output[ii], vmaxtrans), -vmaxtrans)

        # Prepare Twist message
        twist_msg = Twist()
        twist_msg.linear.x = output[0]  # Linear velocity in x-axis
        twist_msg.linear.y = output[1]  # Linear velocity in y-axis
        twist_msg.linear.z = output[2]  # Linear velocity in z-axis

        # Prepare processed data string
        processed_data = (
            "Processed PoseUpdate: global_x=%.2f, global_y=%.2f, global_z=%.2f | "
            "Control (twist): x=%.2f, y=%.2f, z=%.2f"
            % (pose[0], pose[1], pose[2], output[0], output[1], output[2])
        )

        # Publish processed data and twist
        processed_pub.publish(processed_data)
        twist_pub.publish(twist_msg)

        # Log information
        rospy.loginfo(
            "Position processed (linear vel): x=%.2f, y=%.2f, z=%.2f | "
            "Control: x=%.2f, y=%.2f, z=%.2f | global: x=%.2f, y=%.2f, z=%.2f",
            twist_msg.linear.x,
            twist_msg.linear.y,
            twist_msg.linear.z,
            output[0],
            output[1],
            output[2],
            pose[0],
            pose[1],
            pose[2]
        )

    except Exception as e:
        rospy.logwarn("Failed to process pose: %s", str(e))

# Main function
if __name__ == "__main__":
    # Initialize ROS node
    rospy.init_node("data_processor", anonymous=True)

    # TF2 Buffer and Listener for transformations
    tf_buffer = tf2_ros.Buffer()
    tf_listener = tf2_ros.TransformListener(tf_buffer)

    # Publishers for processed data and twist
    processed_pub = rospy.Publisher("processed_data", String, queue_size=10)
    twist_pub = rospy.Publisher("cmd_vel", Twist, queue_size=10)

    # Subscriber for /slam_out_pose
    rospy.Subscriber("/slam_out_pose", PoseStamped, poseupdate_callback)

    # Spin to keep node running
    rospy.spin()
